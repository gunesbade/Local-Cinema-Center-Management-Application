package com.example.cinemacentermanagement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InventoryManagementController {

    @FXML
    private TableView<Product> inventoryTable;

    @FXML
    private TableColumn<Product, String> productColumn;

    @FXML
    private TableColumn<Product, Integer> stockColumn;

    @FXML
    private TextField stockIncreaseField;

    @FXML
    private Button updateStockButton;

    private final ObservableList<Product> productInventory = FXCollections.observableArrayList();

    public void initialize() {
        configureTable();
        loadInventory();
        updateStockButton.setOnAction(event -> updateStock());
    }

    private void configureTable() {
        // Set up table columns
        productColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        stockColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        inventoryTable.setItems(productInventory);
    }

    private void loadInventory() {
        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM inventory")) {

            ResultSet resultSet = statement.executeQuery();

            productInventory.clear(); // Clear existing data
            while (resultSet.next()) {
                String productName = resultSet.getString("product_name");
                int stock = resultSet.getInt("stock_quantity");
                productInventory.add(new Product(productName, stock));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load inventory: " + e.getMessage());
        }
    }

    private void updateStock() {
        Product selectedProduct = inventoryTable.getSelectionModel().getSelectedItem();
        if (selectedProduct == null || stockIncreaseField.getText().isEmpty()) {
            showAlert("Error", "Please select a product and enter a valid stock quantity.");
            return;
        }

        int increaseAmount;
        try {
            increaseAmount = Integer.parseInt(stockIncreaseField.getText());
            if (increaseAmount < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            showAlert("Error", "Stock quantity must be a positive numeric value.");
            return;
        }

        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement(
                     "UPDATE inventory SET stock_quantity = stock_quantity + ? WHERE product_name = ?")) {

            statement.setInt(1, increaseAmount);
            statement.setString(2, selectedProduct.getName());
            int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated > 0) {
                selectedProduct.setStock(selectedProduct.getStock() + increaseAmount);
                inventoryTable.refresh();
                stockIncreaseField.clear();
                showAlert("Success", "Stock updated successfully.");
            } else {
                showAlert("Error", "Failed to update stock.");
            }

        } catch (SQLException e) {
            showAlert("Error", "Database error: " + e.getMessage());
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static class Product {
        private final String name;
        private int stock;

        public Product(String name, int stock) {
            this.name = name;
            this.stock = stock;
        }

        public String getName() {
            return name;
        }

        public int getStock() {
            return stock;
        }

        public void setStock(int stock) {
            this.stock = stock;
        }
    }
}
