package com.example.cinemacentermanagement;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button loginButton;

    @FXML
    private Label errorLabel;

    public void initialize() {
        // Login Button Action
        loginButton.setOnAction(event -> handleLogin());
    }

    private void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            errorLabel.setText("Please fill in both fields.");
            return;
        }

        if (authenticateUser(username, password)) {
            try {
                // Oturum bilgilerini ayarla
                HelloApplication.setCurrentUsername(username);

                // Kullanıcının rolüne göre yönlendirme
                String role = fetchRoleFromDB(username);
                Stage stage = (Stage) loginButton.getScene().getWindow();
                stage.close();

                switch (role) {
                    case "admin" -> openPanel("AdminPanel.fxml", "Admin Panel");
                    case "manager" -> openPanel("ManagerPanel.fxml", "Manager Panel");
                    case "cashier" -> openPanel("CashierPanel.fxml", "Cashier Panel");
                    default -> errorLabel.setText("Role not recognized.");
                }
            } catch (Exception e) {
                errorLabel.setText("Failed to open the panel.");
                e.printStackTrace();
            }
        } else {
            errorLabel.setText("Invalid username or password.");
        }
    }

    private boolean authenticateUser(String username, String password) {
        String query = "SELECT * FROM users WHERE username = ? AND password = ?";
        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, username);
            statement.setString(2, password);
            ResultSet resultSet = statement.executeQuery();

            return resultSet.next();
        } catch (Exception e) {
            errorLabel.setText("Database connection error.");
            e.printStackTrace();
        }
        return false;
    }

    private String fetchRoleFromDB(String username) {
        String query = "SELECT role FROM users WHERE username = ?";
        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getString("role");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "Unknown";
    }

    private void openPanel(String fxmlFile, String title) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/cinemacentermanagement/" + fxmlFile));
        Stage stage = new Stage();
        Scene scene = new Scene(fxmlLoader.load(), 800, 600);

        // Controller'a oturum bilgilerini ilet
        Object controller = fxmlLoader.getController();
        if (controller instanceof ManagerPanelController) {
            ((ManagerPanelController) controller).setUserInfo(HelloApplication.getCurrentUsername(), fetchRoleFromDB(HelloApplication.getCurrentUsername()));
        }

        stage.setTitle(title);
        stage.setScene(scene);
        stage.show();
    }

}
