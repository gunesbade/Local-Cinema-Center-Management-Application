package com.example.cinemacentermanagement;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class HelloApplication extends Application {

    private static String currentRole;
    private static String currentUsername; // Kullanıcı adı saklamak için

    @Override
    public void start(Stage stage) throws Exception {
        // Başlangıç olarak Login ekranını yükle
        openLoginPage(stage);
    }

    public static void main(String[] args) {
        launch();
    }

    private void openLoginPage(Stage stage) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/cinemacentermanagement/Login.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 600);
            stage.setTitle("Login Page");
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            System.err.println("Failed to load Login page.");
            e.printStackTrace();
        }
    }

    public static void handleLoginSuccess(Stage stage, String role) {
        currentRole = role;
        String fxmlFile;
        String title;

        // Role'ye göre panel bilgilerini belirle
        switch (role.toLowerCase()) {
            case "admin" -> {
                fxmlFile = "AdminPanel.fxml";
                title = "Admin Panel";
            }
            case "manager" -> {
                fxmlFile = "ManagerPanel.fxml";
                title = "Manager Panel";
            }
            case "cashier" -> {
                fxmlFile = "CashierPanel.fxml";
                title = "Cashier Panel";
            }
            default -> {
                System.err.println("Unknown role: " + role);
                return;
            }
        }

        // Paneli aç
        openPanel(stage, fxmlFile, title);
    }

    private static void openPanel(Stage stage, String fxmlFile, String title) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("/com/example/cinemacentermanagement/" + fxmlFile));
            Scene scene = new Scene(fxmlLoader.load(), 800, 600);
            stage.setTitle(title);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            System.err.println("Failed to load " + title + " page.");
            e.printStackTrace();
        }
    }

    // Kullanıcı adını saklamak için setter ve getter
    public static void setCurrentUsername(String username) {
        currentUsername = username;
    }

    public static String getCurrentUsername() {
        return currentUsername;
    }
}
