package com.example.cinemacentermanagement;

import javafx.fxml.FXML;
import javafx.scene.control.TabPane;

public class ManagerPanelController {

    @FXML
    private TabPane managerTabPane;

    public void initialize() {
        // Gerekirse, sekmelerin başlangıç durumu burada ayarlanabilir.
        System.out.println("Manager Panel initialized.");
    }
}
