package com.example.cinemacentermanagement;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ManagerPanelController {

    @FXML
    private Label usernameLabel;

    @FXML
    private Label roleLabel;

    @FXML
    private Button logoutButton;

    /**
     * Kullanıcı bilgilerini göstermek için kullanılan metot.
     *
     * @param username Giriş yapan kullanıcının adı.
     * @param role     Giriş yapan kullanıcının rolü.
     */
    public void setUserInfo(String username, String role) {
        usernameLabel.setText("User: " + username);
        roleLabel.setText("- Role: " + role);
    }

    @FXML
    public void initialize() {
        // Logout butonuna tıklama işlemi
        logoutButton.setOnAction(event -> handleLogout());
    }

    /**
     * Log Out işlemini gerçekleştiren metot.
     */
    private void handleLogout() {
        try {
            // Mevcut sahneyi kapat
            Stage currentStage = (Stage) logoutButton.getScene().getWindow();
            currentStage.close();

            // Login ekranını tekrar yükle
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/cinemacentermanagement/Login.fxml"));
            Stage loginStage = new Stage();
            Scene loginScene = new Scene(fxmlLoader.load(), 800, 600);
            loginStage.setTitle("Login");
            loginStage.setScene(loginScene);
            loginStage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
