package com.example.cinemacentermanagement;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MonthlyScheduleController {

    private static MonthlyScheduleController instance; // Singleton instance

    @FXML
    private DatePicker monthPicker;

    @FXML
    private ComboBox<String> hallComboBox;

    @FXML
    private ComboBox<String> movieComboBox; // Film seçimi için ComboBox

    @FXML
    private TextField sessionTimeField;

    @FXML
    private TextField durationField; // Duration Field

    @FXML
    private Button saveScheduleButton;

    public MonthlyScheduleController() {
        instance = this; // Singleton instance ataması
    }

    public static MonthlyScheduleController getInstance() {
        return instance;
    }

    @FXML
    public void initialize() {
        loadHalls();
        loadMovies(); // Filmleri yüklemek için çağrı
        saveScheduleButton.setOnAction(event -> saveSchedule());
    }

    private void loadHalls() {
        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement("SELECT hall_name FROM Halls")) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                hallComboBox.getItems().add(resultSet.getString("hall_name"));
            }
        } catch (Exception e) {
            showAlert("Error", "Failed to load halls: " + e.getMessage());
        }
    }

    public void loadMovies() {
        movieComboBox.getItems().clear(); // Mevcut öğeleri temizle
        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement("SELECT title FROM Movies")) { // 'movie_name' yerine 'title'
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                movieComboBox.getItems().add(resultSet.getString("title")); // 'movie_name' yerine 'title'
            }
        } catch (Exception e) {
            showAlert("Error", "Failed to load movies: " + e.getMessage());
        }
    }

    private void saveSchedule() {
        String movieTitle = movieComboBox.getValue();
        String hallName = hallComboBox.getValue();
        String sessionDate = (monthPicker.getValue() != null) ? monthPicker.getValue().toString() : null;
        String sessionTime = sessionTimeField.getText();
        String duration = durationField.getText();

        if (movieTitle == null || hallName == null || sessionDate == null || sessionTime.isEmpty() || duration.isEmpty()) {
            showAlert("Error", "Please fill in all fields.");
            return;
        }

        // Ensure duration is numeric.
        if (!isNumeric(duration)) {
            showAlert("Error", "Duration must be a numeric value.");
            return;
        }

        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement getMovieId = connection.prepareStatement("SELECT movie_id FROM Movies WHERE title = ?");
             PreparedStatement getHallId = connection.prepareStatement("SELECT hall_id FROM Halls WHERE hall_name = ?");
             PreparedStatement insertSchedule = connection.prepareStatement(
                     "INSERT INTO MonthlySchedule (movie_id, title, hall_id, session_time, session_date, duration) VALUES (?, ?, ?, ?, ?, ?)")) {

            // Fetch movie_id
            getMovieId.setString(1, movieTitle);
            ResultSet movieResult = getMovieId.executeQuery();
            if (!movieResult.next()) {
                showAlert("Error", "Selected movie not found.");
                return;
            }
            int movieId = movieResult.getInt("movie_id");

            // Fetch hall_id
            getHallId.setString(1, hallName);
            ResultSet hallResult = getHallId.executeQuery();
            if (!hallResult.next()) {
                showAlert("Error", "Selected hall not found.");
                return;
            }
            int hallId = hallResult.getInt("hall_id");

            // Insert into MonthlySchedule
            insertSchedule.setInt(1, movieId); // movie_id
            insertSchedule.setString(2, movieTitle); // title
            insertSchedule.setInt(3, hallId); // hall_id
            insertSchedule.setString(4, sessionTime); // session_time
            insertSchedule.setString(5, sessionDate); // session_date
            insertSchedule.setInt(6, Integer.parseInt(duration)); // duration
            insertSchedule.executeUpdate();

            showAlert("Success", "Schedule saved successfully!");
            clearFields();
        } catch (Exception e) {
            showAlert("Error", "Failed to save schedule: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void clearFields() {
        monthPicker.setValue(null);
        hallComboBox.getSelectionModel().clearSelection();
        movieComboBox.getSelectionModel().clearSelection();
        sessionTimeField.clear();
        durationField.clear(); // Clear Duration Field
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
