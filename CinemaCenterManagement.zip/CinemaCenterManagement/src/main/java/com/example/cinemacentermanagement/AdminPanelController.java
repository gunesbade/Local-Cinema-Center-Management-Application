package com.example.cinemacentermanagement;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AdminPanelController {

    @FXML
    private Button logoutButton;

    @FXML
    private Label userInfoLabel;

    @FXML
    private TabPane adminTabPane;

    public void initialize() {
        // Sahne hazır olduğunda pencerenin başlığını ayarla
        Platform.runLater(() -> {
            Stage stage = (Stage) logoutButton.getScene().getWindow();
            stage.setTitle("Group2 CinemaCenter");
        });

        // Kullanıcı bilgilerini dinamik olarak göster
        String username = HelloApplication.getCurrentUsername();
        String role = fetchRoleFromDB(username);
        userInfoLabel.setText("User: " + username + " - Role: " + role);

        // Log Out butonuna tıklama işlemi
        logoutButton.setOnAction(event -> logout());

        // Tab'lerin kapatılmasını engelle
        for (Tab tab : adminTabPane.getTabs()) {
            tab.setClosable(false);
        }
    }

    private String fetchRoleFromDB(String username) {
        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement("SELECT role FROM users WHERE username = ?")) {

            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getString("role");
            }
        } catch (Exception e) {
            System.err.println("Error fetching role: " + e.getMessage());
            e.printStackTrace();
        }
        return "Unknown";
    }

    private void logout() {
        try {
            // Mevcut sahneyi kapat
            Stage stage = (Stage) logoutButton.getScene().getWindow();
            stage.close();

            // Giriş ekranını aç
            HelloApplication mainApp = new HelloApplication();
            Stage loginStage = new Stage();
            mainApp.start(loginStage);
        } catch (Exception e) {
            System.err.println("An error occurred while logging out: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void setUserSession(String username, String role) {
        // Kullanıcı oturum bilgilerini ayarlamak için bir yöntem
        System.out.println("User session set: " + username + ", Role: " + role);
    }

    private void refreshUI() {
        // Kullanıcı bilgilerini yeniden yüklemek için bir yardımcı metot
        String username = HelloApplication.getCurrentUsername();
        String role = fetchRoleFromDB(username);
        userInfoLabel.setText("User: " + username + " - Role: " + role);
    }

    private void displayError(String message) {
        // Hata mesajlarını göstermek için bir metot
        System.err.println("Error: " + message);
    }

    private boolean validateUserAccess(String role) {
        // Kullanıcının erişim yetkisini kontrol etmek için bir metot
        return role.equalsIgnoreCase("admin");
    }
}
