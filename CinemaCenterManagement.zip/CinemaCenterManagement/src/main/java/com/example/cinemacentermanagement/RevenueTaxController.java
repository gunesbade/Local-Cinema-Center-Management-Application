package com.example.cinemacentermanagement;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RevenueTaxController {

    @FXML
    private TextField totalRevenueField;

    @FXML
    private TextField totalTaxField;

    @FXML
    private Button saveButton;

    public void initialize() {
        // Veritabanından toplam gelir ve vergi miktarını yükle
        loadRevenueAndTaxDetails();

        // Kaydet butonuna tıklama işlemi
        saveButton.setOnAction(event -> saveRevenueAndTaxDetails());
    }

    private void loadRevenueAndTaxDetails() {
        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement("SELECT total_revenue, total_tax FROM revenue_tax")) {

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                double totalRevenue = resultSet.getDouble("total_revenue");
                double totalTax = resultSet.getDouble("total_tax");

                // Elde edilen verileri metin alanlarına yazdır
                totalRevenueField.setText(String.format("%.2f", totalRevenue));
                totalTaxField.setText(String.format("%.2f", totalTax));
            } else {
                // Eğer sonuç bulunamazsa
                showAlert("No Data", "No revenue or tax data found in the database.");
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load revenue and tax details: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void saveRevenueAndTaxDetails() {
        String revenueText = totalRevenueField.getText();
        String taxText = totalTaxField.getText();

        if (revenueText.isEmpty() || taxText.isEmpty()) {
            showAlert("Error", "Please fill in both revenue and tax fields before saving.");
            return;
        }

        try {
            double totalRevenue = Double.parseDouble(revenueText);
            double totalTax = Double.parseDouble(taxText);

            try (Connection connection = DatabaseConnection.connect();
                 PreparedStatement statement = connection.prepareStatement(
                         "UPDATE revenue_tax SET total_revenue = ?, total_tax = ?")) {

                statement.setDouble(1, totalRevenue);
                statement.setDouble(2, totalTax);
                int rowsAffected = statement.executeUpdate();

                if (rowsAffected > 0) {
                    showAlert("Success", "Revenue and tax details updated successfully.");
                } else {
                    showAlert("Error", "Failed to update revenue and tax details. No rows affected.");
                }
            }
        } catch (NumberFormatException e) {
            showAlert("Error", "Please enter valid numeric values for revenue and tax.");
        } catch (SQLException e) {
            showAlert("Error", "Failed to save revenue and tax details: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
