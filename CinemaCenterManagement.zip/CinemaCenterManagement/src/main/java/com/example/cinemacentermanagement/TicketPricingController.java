package com.example.cinemacentermanagement;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class TicketPricingController {

    @FXML
    private TextField ticketPriceField;

    @FXML
    private TextField productPriceField;

    @FXML
    private TextField discountRateField;

    @FXML
    private Button saveButton;

    public void initialize() {
        // Mevcut fiyat detaylarını yükle
        loadPricingDetails();

        // Kaydet butonuna tıklama işlemi
        saveButton.setOnAction(event -> savePricingDetails());
    }

    private void loadPricingDetails() {
        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM pricing")) {

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                // Veritabanından çekilen verileri alanlara yaz
                ticketPriceField.setText(String.valueOf(resultSet.getDouble("ticket_price")));
                productPriceField.setText(String.valueOf(resultSet.getDouble("product_price")));
                discountRateField.setText(String.valueOf(resultSet.getDouble("discount_rate")));
            }
        } catch (Exception e) {
            showAlert("Error", "Failed to load pricing details: " + e.getMessage());
        }
    }

    private void savePricingDetails() {
        // Kullanıcı tarafından girilen değerleri al
        String ticketPrice = ticketPriceField.getText();
        String productPrice = productPriceField.getText();
        String discountRate = discountRateField.getText();

        if (ticketPrice.isEmpty() || productPrice.isEmpty() || discountRate.isEmpty()) {
            showAlert("Error", "All fields are required.");
            return;
        }

        // Sayısal doğrulama
        if (!isNumeric(ticketPrice) || !isNumeric(productPrice) || !isNumeric(discountRate)) {
            showAlert("Error", "All fields must contain numeric values.");
            return;
        }

        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement(
                     "UPDATE pricing SET ticket_price = ?, product_price = ?, discount_rate = ?")) {

            // Yeni değerleri veritabanına kaydet
            statement.setDouble(1, Double.parseDouble(ticketPrice));
            statement.setDouble(2, Double.parseDouble(productPrice));
            statement.setDouble(3, Double.parseDouble(discountRate));
            statement.executeUpdate();

            showAlert("Success", "Pricing details updated successfully.");
        } catch (Exception e) {
            showAlert("Error", "Failed to save pricing details: " + e.getMessage());
        }
    }

    private boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
