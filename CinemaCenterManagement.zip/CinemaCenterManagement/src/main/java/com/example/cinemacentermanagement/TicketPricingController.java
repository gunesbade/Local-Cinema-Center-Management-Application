package com.example.cinemacentermanagement;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class TicketPricingController {

    @FXML
    private TextField ticketPriceField;

    @FXML
    private TextField productPriceField;

    @FXML
    private TextField discountRateField;

    @FXML
    private Button saveButton;

    public void initialize() {
        // Load existing pricing details from the database
        loadPricingDetails();

        // Save button action
        saveButton.setOnAction(event -> savePricingDetails());
    }

    private void loadPricingDetails() {
        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM pricing WHERE customer_type='standard'")) {

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                // Load standard pricing into fields as the base values
                ticketPriceField.setText(String.valueOf(resultSet.getDouble("ticket_price")));
                productPriceField.setText(String.valueOf(resultSet.getDouble("product_price")));
                discountRateField.setText(String.valueOf(resultSet.getDouble("discount_rate")));
            }
        } catch (Exception e) {
            showAlert("Error", "Failed to load pricing details: " + e.getMessage());
        }
    }

    private void savePricingDetails() {
        String ticketPrice = ticketPriceField.getText();
        String productPrice = productPriceField.getText();
        String discountRate = discountRateField.getText();

        if (ticketPrice.isEmpty() || productPrice.isEmpty() || discountRate.isEmpty()) {
            showAlert("Error", "All fields are required.");
            return;
        }

        if (!isNumeric(ticketPrice) || !isNumeric(productPrice) || !isNumeric(discountRate)) {
            showAlert("Error", "All fields must contain numeric values.");
            return;
        }

        try (Connection connection = DatabaseConnection.connect()) {
            // Update standard pricing
            updatePricing(connection, "standard", ticketPrice, productPrice, discountRate);

            // Calculate discounted ticket price for other customer types
            double ticketPriceValue = Double.parseDouble(ticketPrice);
            double discountRateValue = Double.parseDouble(discountRate) / 100.0;

            double discountedTicketPrice = ticketPriceValue * (1 - discountRateValue);

            // Update student and senior pricing
            updatePricing(connection, "student", String.valueOf(discountedTicketPrice), productPrice, discountRate);
            updatePricing(connection, "senior", String.valueOf(discountedTicketPrice), productPrice, discountRate);

            showAlert("Success", "Pricing details updated successfully.");
        } catch (Exception e) {
            showAlert("Error", "Failed to save pricing details: " + e.getMessage());
        }
    }

    private void updatePricing(Connection connection, String customerType, String ticketPrice, String productPrice, String discountRate) throws Exception {
        String query = "UPDATE pricing SET ticket_price = ?, product_price = ?, discount_rate = ? WHERE customer_type = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setDouble(1, Double.parseDouble(ticketPrice));
            statement.setDouble(2, Double.parseDouble(productPrice)); // No discount applied
            statement.setDouble(3, Double.parseDouble(discountRate));
            statement.setString(4, customerType);
            statement.executeUpdate();
        }
    }

    private boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
