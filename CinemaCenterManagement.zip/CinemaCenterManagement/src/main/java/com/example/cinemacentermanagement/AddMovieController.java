package com.example.cinemacentermanagement;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class AddMovieController {

    @FXML
    private TextField titleField;

    @FXML
    private TextField genreField;

    @FXML
    private TextArea summaryField;

    @FXML
    private Button choosePosterButton;

    @FXML
    private Label posterLabel;

    @FXML
    private Button saveButton;

    private File posterFile;

    @FXML
    public void initialize() {
        choosePosterButton.setOnAction(event -> choosePoster());
        saveButton.setOnAction(event -> saveMovie());
    }

    private void choosePoster() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"));
        posterFile = fileChooser.showOpenDialog(null);
        if (posterFile != null) {
            posterLabel.setText(posterFile.getName());
        } else {
            posterLabel.setText("No file selected");
        }
    }

    private void saveMovie() {
        String movieTitle = titleField.getText(); // 'movieName' yerine 'movieTitle' olarak güncellendi
        String genre = genreField.getText();
        String summary = summaryField.getText();
        String posterPath = (posterFile != null) ? posterFile.getAbsolutePath() : null;

        if (movieTitle.isEmpty() || genre.isEmpty() || summary.isEmpty()) {
            showAlert("Error", "Please fill in all fields.");
            return;
        }

        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement(
                     "INSERT INTO Movies (title, genre, summary, poster_path) VALUES (?, ?, ?, ?)")) { // 'movie_name' yerine 'title'

            statement.setString(1, movieTitle);
            statement.setString(2, genre);
            statement.setString(3, summary);
            statement.setString(4, posterPath);
            statement.executeUpdate();

            showAlert("Success", "Movie added successfully!");

            // Update UpdateMovieController's ComboBox
            UpdateMovieController updateMovieController = UpdateMovieController.getInstance();
            if (updateMovieController != null) {
                updateMovieController.loadMovies();
            }

            // Update MonthlyScheduleController's ComboBox
            MonthlyScheduleController monthlyScheduleController = MonthlyScheduleController.getInstance();
            if (monthlyScheduleController != null) {
                monthlyScheduleController.loadMovies();
            }

            clearFields();
        } catch (Exception e) {
            showAlert("Error", "Failed to add movie: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void clearFields() {
        titleField.clear();
        genreField.clear();
        summaryField.clear();
        posterLabel.setText("No file selected");
        posterFile = null;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
