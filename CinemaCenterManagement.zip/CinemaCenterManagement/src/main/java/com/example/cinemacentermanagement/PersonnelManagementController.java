package com.example.cinemacentermanagement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PersonnelManagementController {

    @FXML
    private TableView<Personnel> personnelTable;

    @FXML
    private TableColumn<Personnel, String> firstNameColumn;

    @FXML
    private TableColumn<Personnel, String> lastNameColumn;

    @FXML
    private TableColumn<Personnel, String> usernameColumn;

    @FXML
    private TableColumn<Personnel, String> roleColumn;

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private ComboBox<String> roleComboBox;

    @FXML
    private Button addButton;

    @FXML
    private Button updateButton;

    @FXML
    private Button deleteButton;

    private final ObservableList<Personnel> personnelList = FXCollections.observableArrayList();

    public void initialize() {
        configureTable();
        loadPersonnel();
        roleComboBox.getItems().addAll("admin", "manager", "cashier");

        addButton.setOnAction(event -> addPersonnel());
        updateButton.setOnAction(event -> updatePersonnel());
        deleteButton.setOnAction(event -> deletePersonnel());

        personnelTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                fillFields(newSelection);
                updateButton.setDisable(false);
                deleteButton.setDisable(false);
            } else {
                clearFields();
                updateButton.setDisable(true);
                deleteButton.setDisable(true);
            }
        });
    }

    private void configureTable() {
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        roleColumn.setCellValueFactory(new PropertyValueFactory<>("role"));
        personnelTable.setItems(personnelList);
    }

    private void loadPersonnel() {
        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement("SELECT firstname, lastname, username, password, role FROM Users")) {

            ResultSet resultSet = statement.executeQuery();
            personnelList.clear();

            while (resultSet.next()) {
                String firstName = resultSet.getString("firstname");
                String lastName = resultSet.getString("lastname");
                String username = resultSet.getString("username");
                String password = resultSet.getString("password");
                String role = resultSet.getString("role");
                personnelList.add(new Personnel(firstName, lastName, username, password, role));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load users: " + e.getMessage());
        }
    }

    private void addPersonnel() {
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String username = usernameField.getText();
        String password = passwordField.getText();
        String role = roleComboBox.getValue();

        if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || password.isEmpty() || role == null) {
            showAlert("Error", "All fields are required.");
            return;
        }

        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement(
                     "INSERT INTO Users (firstname, lastname, username, password, role) VALUES (?, ?, ?, ?, ?)")) {

            statement.setString(1, firstName);
            statement.setString(2, lastName);
            statement.setString(3, username);
            statement.setString(4, password);
            statement.setString(5, role);
            statement.executeUpdate();

            personnelList.add(new Personnel(firstName, lastName, username, password, role));
            clearFields();
            showAlert("Success", "User added successfully.");
        } catch (SQLException e) {
            showAlert("Error", "Failed to add user: " + e.getMessage());
        }
    }

    private void updatePersonnel() {
        Personnel selectedPersonnel = personnelTable.getSelectionModel().getSelectedItem();

        if (selectedPersonnel == null) {
            showAlert("Error", "Please select a user to update.");
            return;
        }

        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String password = passwordField.getText();
        String role = roleComboBox.getValue();

        if (firstName.isEmpty() || lastName.isEmpty() || role == null) {
            showAlert("Error", "All fields except password are required.");
            return;
        }

        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement(
                     "UPDATE Users SET firstname = ?, lastname = ?, role = ?, password = ? WHERE username = ?")) {

            statement.setString(1, firstName);
            statement.setString(2, lastName);
            statement.setString(3, role);
            statement.setString(4, password.isEmpty() ? selectedPersonnel.getPassword() : password);
            statement.setString(5, selectedPersonnel.getUsername());

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                selectedPersonnel.setFirstName(firstName);
                selectedPersonnel.setLastName(lastName);
                selectedPersonnel.setRole(role);
                if (!password.isEmpty()) {
                    selectedPersonnel.setPassword(password);
                }
                personnelTable.refresh();
                clearFields();
                showAlert("Success", "User updated successfully.");
            } else {
                showAlert("Error", "Failed to update user.");
            }
        } catch (SQLException e) {
            showAlert("Error", "Database error: " + e.getMessage());
        }
    }

    private void deletePersonnel() {
        Personnel selectedPersonnel = personnelTable.getSelectionModel().getSelectedItem();

        if (selectedPersonnel == null) {
            showAlert("Error", "Please select a user to delete.");
            return;
        }

        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement("DELETE FROM Users WHERE username = ?")) {

            statement.setString(1, selectedPersonnel.getUsername());

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                personnelList.remove(selectedPersonnel);
                personnelTable.refresh();
                clearFields();
                showAlert("Success", "User deleted successfully.");
            } else {
                showAlert("Error", "Failed to delete user.");
            }
        } catch (SQLException e) {
            showAlert("Error", "Database error: " + e.getMessage());
        }
    }

    private void clearFields() {
        firstNameField.clear();
        lastNameField.clear();
        usernameField.clear();
        passwordField.clear();
        roleComboBox.getSelectionModel().clearSelection();
    }

    private void fillFields(Personnel personnel) {
        firstNameField.setText(personnel.getFirstName());
        lastNameField.setText(personnel.getLastName());
        usernameField.setText(personnel.getUsername());
        passwordField.clear(); // Güvenlik için şifreyi temizle
        roleComboBox.setValue(personnel.getRole());
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static class Personnel {
        private String firstName;
        private String lastName;
        private String username;
        private String password; // Hidden field
        private String role;

        public Personnel(String firstName, String lastName, String username, String password, String role) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.username = username;
            this.password = password;
            this.role = role;
        }

        public String getFirstName() {
            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getRole() {
            return role;
        }

        public void setRole(String role) {
            this.role = role;
        }
    }
}
