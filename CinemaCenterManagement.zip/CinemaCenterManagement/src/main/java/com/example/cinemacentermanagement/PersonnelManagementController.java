package com.example.cinemacentermanagement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PersonnelManagementController {

    @FXML
    private TableView<Personnel> personnelTable;

    @FXML
    private TableColumn<Personnel, String> firstNameColumn;

    @FXML
    private TableColumn<Personnel, String> lastNameColumn;

    @FXML
    private TableColumn<Personnel, String> usernameColumn;

    @FXML
    private TableColumn<Personnel, String> roleColumn;

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private TextField usernameField;

    @FXML
    private TextField passwordField;

    @FXML
    private ComboBox<String> roleComboBox;

    @FXML
    private Button addButton;

    @FXML
    private Button updateButton;

    @FXML
    private Button deleteButton;

    private final ObservableList<Personnel> personnelList = FXCollections.observableArrayList();

    public void initialize() {
        configureTable();
        loadPersonnel();
        roleComboBox.getItems().addAll("Admin", "Manager", "Cashier"); // Rolleri ekle

        addButton.setOnAction(event -> addPersonnel());
        updateButton.setOnAction(event -> updatePersonnel());
        deleteButton.setOnAction(event -> deletePersonnel());
    }

    private void configureTable() {
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        roleColumn.setCellValueFactory(new PropertyValueFactory<>("role"));
        personnelTable.setItems(personnelList);
    }

    private void loadPersonnel() {
        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM personnel")) {

            ResultSet resultSet = statement.executeQuery();
            personnelList.clear();

            while (resultSet.next()) {
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                String username = resultSet.getString("username");
                String role = resultSet.getString("role");
                personnelList.add(new Personnel(firstName, lastName, username, role));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load personnel: " + e.getMessage());
        }
    }

    private void addPersonnel() {
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String username = usernameField.getText();
        String password = passwordField.getText();
        String role = roleComboBox.getValue();

        if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || password.isEmpty() || role == null) {
            showAlert("Error", "All fields are required.");
            return;
        }

        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement(
                     "INSERT INTO personnel (first_name, last_name, username, password, role) VALUES (?, ?, ?, ?, ?)")) {

            statement.setString(1, firstName);
            statement.setString(2, lastName);
            statement.setString(3, username);
            statement.setString(4, password);
            statement.setString(5, role);
            statement.executeUpdate();

            personnelList.add(new Personnel(firstName, lastName, username, role));
            clearFields();
            showAlert("Success", "Personnel added successfully.");
        } catch (SQLException e) {
            showAlert("Error", "Failed to add personnel: " + e.getMessage());
        }
    }

    private void updatePersonnel() {
        Personnel selectedPersonnel = personnelTable.getSelectionModel().getSelectedItem();
        if (selectedPersonnel == null) {
            showAlert("Error", "Please select a personnel to update.");
            return;
        }

        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String username = usernameField.getText();
        String password = passwordField.getText();
        String role = roleComboBox.getValue();

        if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || role == null) {
            showAlert("Error", "All fields except password are required.");
            return;
        }

        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement(
                     "UPDATE personnel SET first_name = ?, last_name = ?, username = ?, role = ?, password = ? WHERE username = ?")) {

            statement.setString(1, firstName);
            statement.setString(2, lastName);
            statement.setString(3, username);
            statement.setString(4, role);
            statement.setString(5, password.isEmpty() ? selectedPersonnel.getPassword() : password);
            statement.setString(6, selectedPersonnel.getUsername());
            statement.executeUpdate();

            selectedPersonnel.setFirstName(firstName);
            selectedPersonnel.setLastName(lastName);
            selectedPersonnel.setUsername(username);
            selectedPersonnel.setRole(role);
            personnelTable.refresh();
            clearFields();
            showAlert("Success", "Personnel updated successfully.");
        } catch (SQLException e) {
            showAlert("Error", "Failed to update personnel: " + e.getMessage());
        }
    }

    private void deletePersonnel() {
        Personnel selectedPersonnel = personnelTable.getSelectionModel().getSelectedItem();
        if (selectedPersonnel == null) {
            showAlert("Error", "Please select a personnel to delete.");
            return;
        }

        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement("DELETE FROM personnel WHERE username = ?")) {

            statement.setString(1, selectedPersonnel.getUsername());
            statement.executeUpdate();

            personnelList.remove(selectedPersonnel);
            clearFields();
            showAlert("Success", "Personnel deleted successfully.");
        } catch (SQLException e) {
            showAlert("Error", "Failed to delete personnel: " + e.getMessage());
        }
    }

    private void clearFields() {
        firstNameField.clear();
        lastNameField.clear();
        usernameField.clear();
        passwordField.clear();
        roleComboBox.getSelectionModel().clearSelection();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static class Personnel {
        private String firstName;
        private String lastName;
        private String username;
        private String password; // Gizli alan
        private String role;

        public Personnel(String firstName, String lastName, String username, String role) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.username = username;
            this.role = role;
        }

        public String getFirstName() {
            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getRole() {
            return role;
        }

        public void setRole(String role) {
            this.role = role;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }
    }
}
