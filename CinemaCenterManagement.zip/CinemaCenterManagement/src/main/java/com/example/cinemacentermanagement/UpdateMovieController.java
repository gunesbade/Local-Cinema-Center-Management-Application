package com.example.cinemacentermanagement;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UpdateMovieController {
    private static UpdateMovieController instance;

    public UpdateMovieController() {
        instance = this; // Singleton örneği oluşturma
    }

    public static UpdateMovieController getInstance() {
        return instance; // Singleton nesnesini döndürme
    }

    @FXML
    private ComboBox<String> movieComboBox;

    @FXML
    private TextField genreField;

    @FXML
    private TextArea summaryField;

    @FXML
    private Button updateButton;

    @FXML
    public void initialize() {
        refreshMovies();
        movieComboBox.setOnAction(event -> loadMovieDetails(movieComboBox.getValue()));
        updateButton.setOnAction(event -> updateMovie());
    }

    public void refreshMovies() { // Public olarak düzenlendi
        movieComboBox.getItems().clear(); // Eski öğeleri temizle
        loadMovieTitles();
    }

    public void loadMovieTitles() { // Public olarak düzenlendi
        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement("SELECT title FROM Movies");
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                movieComboBox.getItems().add(resultSet.getString("title"));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load movie titles: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void loadMovies() { // Alternatif yöntem için bırakılmıştır
        movieComboBox.getItems().clear();
        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement("SELECT title FROM Movies")) {
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                movieComboBox.getItems().add(resultSet.getString("title"));
            }
        } catch (Exception e) {
            showAlert("Error", "Failed to load movie titles: " + e.getMessage());
        }
    }

    private void loadMovieDetails(String movieTitle) {
        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM Movies WHERE title = ?")) {

            statement.setString(1, movieTitle);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                genreField.setText(resultSet.getString("genre"));
                summaryField.setText(resultSet.getString("summary"));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load movie details: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void updateMovie() {
        String genre = genreField.getText();
        String summary = summaryField.getText();
        String selectedMovie = movieComboBox.getValue();

        if (genre.isEmpty() || summary.isEmpty() || selectedMovie == null) {
            showAlert("Error", "Please fill in all fields and select a movie.");
            return;
        }

        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement(
                     "UPDATE Movies SET genre = ?, summary = ? WHERE title = ?")) {

            statement.setString(1, genre);
            statement.setString(2, summary);
            statement.setString(3, selectedMovie);
            int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated > 0) {
                showAlert("Success", "Movie updated successfully!");
                clearFields();
                refreshMovies(); // Listeyi güncelle
            } else {
                showAlert("Error", "Failed to update movie. Please try again.");
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to update movie: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void clearFields() {
        genreField.clear();
        summaryField.clear();
        movieComboBox.getSelectionModel().clearSelection();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }

}

