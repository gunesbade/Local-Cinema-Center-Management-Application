package com.example.cinemacentermanagement;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CancellationsController {

    @FXML
    private ComboBox<String> transactionComboBox;

    @FXML
    private Button refundTicketButton;

    @FXML
    private Button refundProductButton;

    @FXML
    private TextArea detailsArea;

    @FXML
    public void initialize() {
        loadTransactions(); // Veritabanından transactionları yükle
        transactionComboBox.setOnAction(event -> displayTransactionDetails(transactionComboBox.getValue()));
        refundTicketButton.setOnAction(event -> processRefund("Ticket"));
        refundProductButton.setOnAction(event -> processRefund("Product"));
    }

    private void loadTransactions() {
        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement("SELECT transaction_id FROM Transactions");
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                transactionComboBox.getItems().add(resultSet.getString("transaction_id"));
            }
        } catch (SQLException e) {
            showAlert("Error", "Failed to load transactions: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void displayTransactionDetails(String transactionId) {
        if (transactionId != null) {
            try (Connection connection = DatabaseConnection.connect();
                 PreparedStatement statement = connection.prepareStatement(
                         "SELECT item_type, item_name, quantity, price FROM TransactionDetails WHERE transaction_id = ?")) {

                statement.setString(1, transactionId);
                ResultSet resultSet = statement.executeQuery();

                StringBuilder details = new StringBuilder();
                while (resultSet.next()) {
                    String itemType = resultSet.getString("item_type");
                    String itemName = resultSet.getString("item_name");
                    int quantity = resultSet.getInt("quantity");
                    double price = resultSet.getDouble("price");

                    details.append(String.format("Type: %s, Item: %s, Quantity: %d, Price: %.2f\n",
                            itemType, itemName, quantity, price));
                }

                detailsArea.setText(details.toString());
            } catch (SQLException e) {
                showAlert("Error", "Failed to load transaction details: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            detailsArea.clear();
        }
    }

    private void processRefund(String refundType) {
        String selectedTransaction = transactionComboBox.getValue();

        if (selectedTransaction == null) {
            showAlert("Error", "Please select a transaction to process the refund.");
            return;
        }

        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement deleteDetailsStatement = connection.prepareStatement(
                     "DELETE FROM TransactionDetails WHERE transaction_id = ? AND item_type = ?");
             PreparedStatement updateTransactionsStatement = connection.prepareStatement(
                     "DELETE FROM Transactions WHERE transaction_id = ? AND NOT EXISTS " +
                             "(SELECT 1 FROM TransactionDetails WHERE transaction_id = ?)")) {

            // Delete the details for the selected refund type
            deleteDetailsStatement.setString(1, selectedTransaction);
            deleteDetailsStatement.setString(2, refundType);
            deleteDetailsStatement.executeUpdate();

            // Check if there are no details left and delete the transaction if needed
            updateTransactionsStatement.setString(1, selectedTransaction);
            updateTransactionsStatement.setString(2, selectedTransaction);
            updateTransactionsStatement.executeUpdate();

            transactionComboBox.getItems().remove(selectedTransaction);
            displayTransactionDetails(null); // Detayları temizle

            showAlert("Success", refundType + " refund processed successfully!");
        } catch (SQLException e) {
            showAlert("Error", "Failed to process refund: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
